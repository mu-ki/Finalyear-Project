package org.opencv.samples.facedetect;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.OpenCVLoader;
import org.opencv.calib3d.Calib3d;
import org.opencv.core.Core;
import org.opencv.core.Core.MinMaxLocResult;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.objdetect.CascadeClassifier;

public class FdActivity extends Activity implements CvCameraViewListener2 {
    private static final Scalar FACE_RECT_COLOR = new Scalar(0.0d, 255.0d, 0.0d, 255.0d);
    public static final int JAVA_DETECTOR = 0;
    private static final String TAG = "OCVSample::Activity";
    int AllTime = 30;
    public int FrameClosedDrowsy = 0;
    int FrameEyesClosed = 0;
    int FrameEyesOpen = 0;
    int FrameFace = 0;
    private boolean HaarEyeOpen_L = false;
    private boolean HaarEyeOpen_R = false;
    private boolean HaarLE = false;
    private boolean HaarRE = false;
    int TotalFrames = 0;
    MediaPlayer beep;
    /* access modifiers changed from: private */
    public int cameraid = 1;
    /* access modifiers changed from: private */
    public File cascadeFileEL;
    /* access modifiers changed from: private */
    public File cascadeFileER;
    /* access modifiers changed from: private */
    public File cascadeFileEyeOpen;
    int count_drowsy = 0;
    boolean drowsy = true;
    int drowsyTime = 1;
    Rect eye_only_rectangle;
    Rect eye_template;
    boolean flag = false;
    boolean flag_drowsy = false;
    double frequency;
    Point iris;
    private int mAbsoluteFaceSize = 0;
    /* access modifiers changed from: private */
    public File mCascadeFile;
    private String[] mDetectorName = new String[2];
    private int mDetectorType = 0;
    private Mat mGray;
    private MenuItem mItemFace20;
    private MenuItem mItemFace30;
    private MenuItem mItemFace40;
    private MenuItem mItemFace50;
    private MenuItem mItemType;
    /* access modifiers changed from: private */
    public CascadeClassifier mJavaDetector;
    /* access modifiers changed from: private */
    public CascadeClassifier mJavaDetectorEyeLeft;
    /* access modifiers changed from: private */
    public CascadeClassifier mJavaDetectorEyeOpen;
    /* access modifiers changed from: private */
    public CascadeClassifier mJavaDetectorEyeRight;
    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        public void onManagerConnected(int status) {
            switch (status) {
                case 0:
                    Log.i(FdActivity.TAG, "OpenCV loaded successfully");
                    try {
                        InputStream is = FdActivity.this.getResources().openRawResource(C0019R.raw.lbpcascade_frontalface);
                        File cascadeDir = FdActivity.this.getDir("cascade", 0);
                        FdActivity fdActivity = FdActivity.this;
                        File file = new File(cascadeDir, "lbpcascade_frontalface.xml");
                        fdActivity.mCascadeFile = file;
                        FileOutputStream fileOutputStream = new FileOutputStream(FdActivity.this.mCascadeFile);
                        byte[] buffer = new byte[Calib3d.CALIB_FIX_K5];
                        while (true) {
                            int bytesRead = is.read(buffer);
                            if (bytesRead == -1) {
                                is.close();
                                fileOutputStream.close();
                                InputStream iser = FdActivity.this.getResources().openRawResource(C0019R.raw.haarcascade_righteye_2splits);
                                File cascadeDirER = FdActivity.this.getDir("cascadeER", 0);
                                FdActivity fdActivity2 = FdActivity.this;
                                File file2 = new File(cascadeDirER, "haarcascade_eye_right.xml");
                                fdActivity2.cascadeFileER = file2;
                                FileOutputStream oser = new FileOutputStream(FdActivity.this.cascadeFileER);
                                byte[] bufferER = new byte[Calib3d.CALIB_FIX_K5];
                                while (true) {
                                    int bytesReadER = iser.read(bufferER);
                                    if (bytesReadER == -1) {
                                        iser.close();
                                        oser.close();
                                        InputStream isel = FdActivity.this.getResources().openRawResource(C0019R.raw.haarcascade_lefteye_2splits);
                                        File cascadeDirEL = FdActivity.this.getDir("cascadeEL", 0);
                                        FdActivity fdActivity3 = FdActivity.this;
                                        File file3 = new File(cascadeDirEL, "haarcascade_eye_left.xml");
                                        fdActivity3.cascadeFileEL = file3;
                                        FileOutputStream fileOutputStream2 = new FileOutputStream(FdActivity.this.cascadeFileEL);
                                        byte[] bufferEL = new byte[Calib3d.CALIB_FIX_K5];
                                        while (true) {
                                            int bytesReadEL = isel.read(bufferEL);
                                            if (bytesReadEL == -1) {
                                                isel.close();
                                                fileOutputStream2.close();
                                                InputStream opisel = FdActivity.this.getResources().openRawResource(C0019R.raw.haarcascade_eye_tree_eyeglasses);
                                                File cascadeDirEyeOpen = FdActivity.this.getDir("cascadeEyeOpen", 0);
                                                FdActivity fdActivity4 = FdActivity.this;
                                                File file4 = new File(cascadeDirEyeOpen, "haarcascade_eye_tree_eyeglasses.xml");
                                                fdActivity4.cascadeFileEyeOpen = file4;
                                                FileOutputStream fileOutputStream3 = new FileOutputStream(FdActivity.this.cascadeFileEyeOpen);
                                                byte[] bufferEyeOpen = new byte[Calib3d.CALIB_FIX_K5];
                                                while (true) {
                                                    int bytesReadEyeOpen = opisel.read(bufferEyeOpen);
                                                    if (bytesReadEyeOpen == -1) {
                                                        opisel.close();
                                                        fileOutputStream3.close();
                                                        FdActivity.this.mJavaDetector = new CascadeClassifier(FdActivity.this.mCascadeFile.getAbsolutePath());
                                                        if (FdActivity.this.mJavaDetector.empty()) {
                                                            Log.e(FdActivity.TAG, "Failed to load cascade classifier of face");
                                                            FdActivity.this.mJavaDetector = null;
                                                        } else {
                                                            Log.i(FdActivity.TAG, "Loaded cascade classifier from " + FdActivity.this.mCascadeFile.getAbsolutePath());
                                                        }
                                                        FdActivity.this.mJavaDetectorEyeRight = new CascadeClassifier(FdActivity.this.cascadeFileER.getAbsolutePath());
                                                        if (FdActivity.this.mJavaDetectorEyeRight.empty()) {
                                                            Log.e(FdActivity.TAG, "Failed to load cascade classifier of eye right");
                                                            FdActivity.this.mJavaDetectorEyeRight = null;
                                                        } else {
                                                            Log.i(FdActivity.TAG, "Loaded cascade classifier from " + FdActivity.this.cascadeFileER.getAbsolutePath());
                                                        }
                                                        FdActivity.this.mJavaDetectorEyeLeft = new CascadeClassifier(FdActivity.this.cascadeFileEL.getAbsolutePath());
                                                        if (FdActivity.this.mJavaDetectorEyeLeft.empty()) {
                                                            Log.e(FdActivity.TAG, "Failed to load cascade classifier of eye left");
                                                            FdActivity.this.mJavaDetectorEyeLeft = null;
                                                        } else {
                                                            Log.i(FdActivity.TAG, "Loaded cascade classifier from " + FdActivity.this.cascadeFileEL.getAbsolutePath());
                                                        }
                                                        FdActivity.this.mJavaDetectorEyeOpen = new CascadeClassifier(FdActivity.this.cascadeFileEyeOpen.getAbsolutePath());
                                                        if (FdActivity.this.mJavaDetectorEyeOpen.empty()) {
                                                            Log.e(FdActivity.TAG, "Failed to load cascade classifier of eye open");
                                                            FdActivity.this.mJavaDetectorEyeOpen = null;
                                                        } else {
                                                            Log.i(FdActivity.TAG, "Loaded cascade classifier from " + FdActivity.this.cascadeFileEyeOpen.getAbsolutePath());
                                                        }
                                                        FdActivity.this.mOpenCvCameraView.setCameraIndex(FdActivity.this.cameraid);
                                                        FdActivity.this.mOpenCvCameraView.enableFpsMeter();
                                                        FdActivity.this.mOpenCvCameraView.enableView();
                                                        return;
                                                    }
                                                    fileOutputStream3.write(bufferEyeOpen, 0, bytesReadEyeOpen);
                                                }
                                            } else {
                                                fileOutputStream2.write(bufferEL, 0, bytesReadEL);
                                            }
                                        }
                                    } else {
                                        oser.write(bufferER, 0, bytesReadER);
                                    }
                                }
                            } else {
                                fileOutputStream.write(buffer, 0, bytesRead);
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.e(FdActivity.TAG, "Failed to load cascade. Exception thrown: " + e);
                    }
                default:
                    super.onManagerConnected(status);
                    return;
            }
        }
    };
    /* access modifiers changed from: private */
    public CameraBridgeViewBase mOpenCvCameraView;
    private float mRelativeFaceSize = 0.2f;
    private Mat mRgba;
    MinMaxLocResult mmG;
    private Mat templateL;
    private Mat templateL_open;
    private Mat templateR;
    private Mat templateR_open;
    long timer;
    long timer_drowsy;

    public FdActivity() {
        this.mDetectorName[0] = "Java";
        Log.i(TAG, "Instantiated new " + getClass());
    }

    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "called onCreate");
        super.onCreate(savedInstanceState);
        getWindow().addFlags(128);
        setContentView(C0019R.layout.face_detect_surface_view);
        this.mOpenCvCameraView = (CameraBridgeViewBase) findViewById(C0019R.C0020id.fd_activity_surface_view);
        this.mOpenCvCameraView.setCvCameraViewListener((CvCameraViewListener2) this);
        this.beep = MediaPlayer.create(this, C0019R.raw.button1);
    }

    public void onPause() {
        super.onPause();
        if (this.mOpenCvCameraView != null) {
            this.mOpenCvCameraView.disableView();
        }
        System.exit(0);
    }

    public void onResume() {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_3, this, this.mLoaderCallback);
    }

    public void onDestroy() {
        super.onDestroy();
        this.mOpenCvCameraView.disableView();
    }

    public void onCameraViewStarted(int width, int height) {
        this.mGray = new Mat();
        this.mRgba = new Mat();
    }

    public void onCameraViewStopped() {
        this.mGray.release();
        this.mRgba.release();
    }

    public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
        if (this.drowsy) {
            this.timer_drowsy = Core.getTickCount();
            this.drowsy = false;
        }
        SetTimer();
        this.mRgba = inputFrame.rgba();
        this.mGray = inputFrame.gray();
        this.TotalFrames++;
        if (SetDrowsy() || this.count_drowsy != 0) {
            this.count_drowsy++;
            Core.putText(this.mRgba, "ALERT!", new Point(this.mRgba.size().width / 2.0d, this.mRgba.size().height / 2.0d), 7, 4.0d, new Scalar(255.0d, 255.0d, 0.0d), 5);
            if (this.count_drowsy > 2) {
                this.count_drowsy = 0;
            }
        }
        if (this.mAbsoluteFaceSize == 0) {
            int height = this.mGray.rows();
            if (Math.round(((float) height) * this.mRelativeFaceSize) > 0) {
                this.mAbsoluteFaceSize = Math.round(((float) height) * this.mRelativeFaceSize);
            }
        }
        MatOfRect faces = new MatOfRect();
        if (this.mJavaDetector != null) {
            this.mJavaDetector.detectMultiScale(this.mGray, faces, 1.1d, 2, 2, new Size((double) this.mAbsoluteFaceSize, (double) this.mAbsoluteFaceSize), new Size());
        }
        Rect[] facesArray = faces.toArray();
        int i = 0;
        while (true) {
            if (i >= facesArray.length) {
                break;
            }
            Core.rectangle(this.mRgba, facesArray[i].mo306tl(), facesArray[i].mo299br(), FACE_RECT_COLOR, 3);
            Rect RectOfFace = facesArray[i];
            Rect rect = new Rect(RectOfFace.f5x + (RectOfFace.width / 16), (int) (((double) RectOfFace.f6y) + (((double) RectOfFace.height) / 4.5d)), (RectOfFace.width - ((RectOfFace.width * 2) / 16)) / 2, (int) (((double) RectOfFace.height) / 3.0d));
            Rect rect2 = new Rect(RectOfFace.f5x + (RectOfFace.width / 16) + ((RectOfFace.width - ((RectOfFace.width * 2) / 16)) / 2), (int) (((double) RectOfFace.f6y) + (((double) RectOfFace.height) / 4.5d)), (RectOfFace.width - ((RectOfFace.width * 2) / 16)) / 2, (int) (((double) RectOfFace.height) / 3.0d));
            this.FrameFace++;
            Rect rectR = get_template(this.mJavaDetectorEyeRight, rect);
            Rect rectL = get_template(this.mJavaDetectorEyeLeft, rect2);
            if (rectL.width == 0 || rectL.height == 0 || rectR.width == 0 || rectR.height == 0) {
                i++;
            } else {
                this.templateR = this.mGray.submat(rectR);
                this.templateL = this.mGray.submat(rectL);
                this.templateR_open = this.mGray.submat(get_template(this.mJavaDetectorEyeOpen, rect));
                this.templateL_open = this.mGray.submat(get_template(this.mJavaDetectorEyeOpen, rect2));
                this.HaarEyeOpen_R = match_eye(this.templateR_open);
                this.HaarEyeOpen_L = match_eye(this.templateL_open);
                this.HaarRE = match_eye(this.templateR);
                this.HaarLE = match_eye(this.templateL);
                if (!this.HaarEyeOpen_R && !this.HaarEyeOpen_L) {
                    Core.putText(this.mRgba, "Closed", new Point(this.mRgba.size().width / 18.0d, this.mRgba.size().height / 5.0d), 7, 4.0d, new Scalar(0.0d, 255.0d, 0.0d), 5);
                    this.FrameEyesClosed++;
                    this.FrameClosedDrowsy++;
                } else if (this.HaarEyeOpen_R && this.HaarEyeOpen_L) {
                    Core.putText(this.mRgba, "Open", new Point(this.mRgba.size().width / 18.0d, this.mRgba.size().height / 5.0d), 7, 4.0d, new Scalar(0.0d, 255.0d, 0.0d), 5);
                    this.FrameEyesOpen++;
                }
            }
        }
        return this.mRgba;
    }

    private Rect get_template(CascadeClassifier clasificator, Rect RectAreaInterest) {
        new Mat();
        Mat mROI = this.mGray.submat(RectAreaInterest);
        MatOfRect eyes = new MatOfRect();
        this.iris = new Point();
        this.eye_template = new Rect();
        clasificator.detectMultiScale(mROI, eyes, 1.1d, 2, 6, new Size(10.0d, 10.0d), new Size(100.0d, 100.0d));
        Rect[] eyesArray = eyes.toArray();
        if (0 < eyesArray.length) {
            Rect eyeDetected = eyesArray[0];
            eyeDetected.f5x = RectAreaInterest.f5x + eyeDetected.f5x;
            eyeDetected.f6y = RectAreaInterest.f6y + eyeDetected.f6y;
            this.mmG = Core.minMaxLoc(this.mGray.submat(eyeDetected));
            this.iris.f0x = this.mmG.minLoc.f0x + ((double) eyeDetected.f5x);
            this.iris.f1y = this.mmG.minLoc.f1y + ((double) eyeDetected.f6y);
            this.eye_template = new Rect(((int) this.iris.f0x) - (eyeDetected.width / 2), ((int) this.iris.f1y) - (eyeDetected.height / 2), eyeDetected.width, eyeDetected.height);
        }
        return this.eye_template;
    }

    private Rect get_template(CascadeClassifier clasificator, Rect RectAreaInterest, Size min_size, Size max_size) {
        new Mat();
        Mat mROI = this.mGray.submat(RectAreaInterest);
        MatOfRect eyes = new MatOfRect();
        this.iris = new Point();
        this.eye_template = new Rect();
        clasificator.detectMultiScale(mROI, eyes, 1.01d, 2, 6, min_size, max_size);
        Rect[] eyesArray = eyes.toArray();
        if (0 < eyesArray.length) {
            Rect eyeDetected = eyesArray[0];
            eyeDetected.f5x = RectAreaInterest.f5x + eyeDetected.f5x;
            eyeDetected.f6y = RectAreaInterest.f6y + eyeDetected.f6y;
            this.mmG = Core.minMaxLoc(this.mGray.submat(eyeDetected));
            this.iris.f0x = this.mmG.minLoc.f0x + ((double) eyeDetected.f5x);
            this.iris.f1y = this.mmG.minLoc.f1y + ((double) eyeDetected.f6y);
            this.eye_template = new Rect(((int) this.iris.f0x) - (eyeDetected.width / 2), ((int) this.iris.f1y) - (eyeDetected.height / 2), eyeDetected.width, eyeDetected.height);
        }
        return this.eye_template;
    }

    private boolean match_eye(Mat mTemplate) {
        if (mTemplate.cols() == 0 || mTemplate.rows() == 0) {
            return false;
        }
        return true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        Log.i(TAG, "called onCreateOptionsMenu");
        this.mItemFace50 = menu.add("Face size 50%");
        this.mItemFace40 = menu.add("Face size 40%");
        this.mItemFace30 = menu.add("Face size 30%");
        this.mItemFace20 = menu.add("Face size 20%");
        this.mItemType = menu.add(this.mDetectorName[this.mDetectorType]);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        Log.i(TAG, "called onOptionsItemSelected; selected item: " + item);
        if (item == this.mItemFace50) {
            setMinFaceSize(0.5f);
        } else if (item == this.mItemFace40) {
            setMinFaceSize(0.4f);
        } else if (item == this.mItemFace30) {
            setMinFaceSize(0.3f);
        } else if (item == this.mItemFace20) {
            setMinFaceSize(0.2f);
        } else if (item == this.mItemType) {
            item.setTitle(this.mDetectorName[(this.mDetectorType + 1) % this.mDetectorName.length]);
        }
        return true;
    }

    private void setMinFaceSize(float faceSize) {
        this.mRelativeFaceSize = faceSize;
        this.mAbsoluteFaceSize = 0;
    }

    public void onToggleClick(View v) {
        this.cameraid ^= 1;
        this.mOpenCvCameraView.disableView();
        this.mOpenCvCameraView.setCameraIndex(this.cameraid);
        this.mOpenCvCameraView.enableView();
    }

    public void InitTimer(View v) {
        Toast.makeText(getApplicationContext(), "Timer enabled for " + this.AllTime + " seconds", 0).show();
        this.frequency = Core.getTickFrequency();
        this.timer = Core.getTickCount();
        this.TotalFrames = 0;
        this.FrameFace = 0;
        this.FrameEyesOpen = 0;
        this.FrameEyesClosed = 0;
        this.flag = true;
    }

    public void SetTimer() {
        long newtimer = Core.getTickCount() - this.timer;
        if (((double) newtimer) / this.frequency > ((double) this.AllTime) && this.flag) {
            if (this.FrameEyesClosed > this.FrameFace) {
                this.FrameEyesClosed = this.FrameFace;
            }
            if (this.FrameEyesOpen > this.FrameFace) {
                this.FrameEyesOpen = this.FrameFace;
            }
            ((AudioManager) getSystemService("audio")).setStreamVolume(3, 10, 0);
            this.beep.start();
            String msg = "Timer: " + newtimer + " Frecuency: " + ((long) this.frequency);
            final String Result = "Total Frames: " + this.TotalFrames + "\nFrames face: " + this.FrameFace + "\nFrames EyesOpen: " + this.FrameEyesOpen + "\nFrames EyesClosed: " + this.FrameEyesClosed;
            Log.i(TAG, msg);
            Log.i(TAG, Result);
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(FdActivity.this.getApplicationContext(), Result, 1).show();
                }
            });
            this.flag = false;
        }
    }

    public boolean SetDrowsy() {
        long newtimer = Core.getTickCount() - this.timer_drowsy;
        this.frequency = Core.getTickFrequency();
        this.flag_drowsy = false;
        if (((double) newtimer) / this.frequency > ((double) this.drowsyTime)) {
            this.timer_drowsy = Core.getTickCount();
            if (this.FrameClosedDrowsy > 2) {
                this.flag_drowsy = true;
            }
            this.FrameClosedDrowsy = 0;
        }
        return this.flag_drowsy;
    }
}
