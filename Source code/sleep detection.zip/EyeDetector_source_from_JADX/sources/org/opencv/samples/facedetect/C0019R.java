package org.opencv.samples.facedetect;

/* renamed from: org.opencv.samples.facedetect.R */
public final class C0019R {

    /* renamed from: org.opencv.samples.facedetect.R$array */
    public static final class array {
        public static final int Preocessing_arrays = 2131099648;
    }

    /* renamed from: org.opencv.samples.facedetect.R$attr */
    public static final class attr {
        public static final int camera_id = 2130771969;
        public static final int show_fps = 2130771968;
    }

    /* renamed from: org.opencv.samples.facedetect.R$drawable */
    public static final class drawable {
        public static final int icon = 2130837504;
    }

    /* renamed from: org.opencv.samples.facedetect.R$id */
    public static final class C0020id {
        public static final int any = 2131165184;
        public static final int back = 2131165185;
        public static final int button = 2131165190;
        public static final int fd_activity_surface_view = 2131165188;
        public static final int front = 2131165186;
        public static final int masterWindow = 2131165187;
        public static final int togglebutton = 2131165189;
    }

    /* renamed from: org.opencv.samples.facedetect.R$layout */
    public static final class layout {
        public static final int face_detect_surface_view = 2130903040;
    }

    /* renamed from: org.opencv.samples.facedetect.R$raw */
    public static final class raw {
        public static final int beep = 2130968576;
        public static final int button1 = 2130968577;
        public static final int haarcascade_eye_tree_eyeglasses = 2130968578;
        public static final int haarcascade_lefteye_2splits = 2130968579;
        public static final int haarcascade_righteye_2splits = 2130968580;
        public static final int lbpcascade_frontalface = 2130968581;
    }

    /* renamed from: org.opencv.samples.facedetect.R$string */
    public static final class string {
        public static final int Processing_prompt = 2131034113;
        public static final int app_name = 2131034112;
    }

    /* renamed from: org.opencv.samples.facedetect.R$styleable */
    public static final class styleable {
        public static final int[] CameraBridgeViewBase = {C0019R.attr.show_fps, C0019R.attr.camera_id};
        public static final int CameraBridgeViewBase_camera_id = 1;
        public static final int CameraBridgeViewBase_show_fps = 0;
    }
}
