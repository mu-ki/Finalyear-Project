package org.opencv.samples.facedetect;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
