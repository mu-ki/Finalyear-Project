package org.opencv;

import org.opencv.samples.facedetect.C0019R;

/* renamed from: org.opencv.R */
public final class C0000R {

    /* renamed from: org.opencv.R$attr */
    public static final class attr {
        public static final int camera_id = 2130771969;
        public static final int show_fps = 2130771968;
    }

    /* renamed from: org.opencv.R$id */
    public static final class C0001id {
        public static final int any = 2131165184;
        public static final int back = 2131165185;
        public static final int front = 2131165186;
    }

    /* renamed from: org.opencv.R$styleable */
    public static final class styleable {
        public static final int[] CameraBridgeViewBase = {C0019R.attr.show_fps, C0019R.attr.camera_id};
        public static final int CameraBridgeViewBase_camera_id = 1;
        public static final int CameraBridgeViewBase_show_fps = 0;
    }
}
