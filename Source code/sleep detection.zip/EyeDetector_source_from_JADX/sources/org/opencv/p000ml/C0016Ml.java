package org.opencv.p000ml;

/* renamed from: org.opencv.ml.Ml */
public class C0016Ml {
}
