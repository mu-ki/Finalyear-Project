package org.opencv.core;

public class Point3 {

    /* renamed from: x */
    public double f2x;

    /* renamed from: y */
    public double f3y;

    /* renamed from: z */
    public double f4z;

    public Point3(double x, double y, double z) {
        this.f2x = x;
        this.f3y = y;
        this.f4z = z;
    }

    public Point3() {
        this(0.0d, 0.0d, 0.0d);
    }

    public Point3(Point p) {
        this.f2x = p.f0x;
        this.f3y = p.f1y;
        this.f4z = 0.0d;
    }

    public Point3(double[] vals) {
        this();
        set(vals);
    }

    public void set(double[] vals) {
        double d;
        double d2 = 0.0d;
        if (vals != null) {
            this.f2x = vals.length > 0 ? vals[0] : 0.0d;
            if (vals.length > 1) {
                d = vals[1];
            } else {
                d = 0.0d;
            }
            this.f3y = d;
            if (vals.length > 2) {
                d2 = vals[2];
            }
            this.f4z = d2;
            return;
        }
        this.f2x = 0.0d;
        this.f3y = 0.0d;
        this.f4z = 0.0d;
    }

    public Point3 clone() {
        return new Point3(this.f2x, this.f3y, this.f4z);
    }

    public double dot(Point3 p) {
        return (this.f2x * p.f2x) + (this.f3y * p.f3y) + (this.f4z * p.f4z);
    }

    public Point3 cross(Point3 p) {
        return new Point3((this.f3y * p.f4z) - (this.f4z * p.f3y), (this.f4z * p.f2x) - (this.f2x * p.f4z), (this.f2x * p.f3y) - (this.f3y * p.f2x));
    }

    public int hashCode() {
        long temp = Double.doubleToLongBits(this.f2x);
        int result = ((int) ((temp >>> 32) ^ temp)) + 31;
        long temp2 = Double.doubleToLongBits(this.f3y);
        int result2 = (result * 31) + ((int) ((temp2 >>> 32) ^ temp2));
        long temp3 = Double.doubleToLongBits(this.f4z);
        return (result2 * 31) + ((int) ((temp3 >>> 32) ^ temp3));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Point3)) {
            return false;
        }
        Point3 it = (Point3) obj;
        if (this.f2x == it.f2x && this.f3y == it.f3y && this.f4z == it.f4z) {
            return true;
        }
        return false;
    }

    public String toString() {
        return "{" + this.f2x + ", " + this.f3y + ", " + this.f4z + "}";
    }
}
