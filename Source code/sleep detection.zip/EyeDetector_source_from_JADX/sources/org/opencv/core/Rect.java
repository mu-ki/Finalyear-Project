package org.opencv.core;

public class Rect {
    public int height;
    public int width;

    /* renamed from: x */
    public int f5x;

    /* renamed from: y */
    public int f6y;

    public Rect(int x, int y, int width2, int height2) {
        this.f5x = x;
        this.f6y = y;
        this.width = width2;
        this.height = height2;
    }

    public Rect() {
        this(0, 0, 0, 0);
    }

    public Rect(Point p1, Point p2) {
        this.f5x = (int) (p1.f0x < p2.f0x ? p1.f0x : p2.f0x);
        this.f6y = (int) (p1.f1y < p2.f1y ? p1.f1y : p2.f1y);
        this.width = ((int) (p1.f0x > p2.f0x ? p1.f0x : p2.f0x)) - this.f5x;
        this.height = ((int) (p1.f1y > p2.f1y ? p1.f1y : p2.f1y)) - this.f6y;
    }

    public Rect(Point p, Size s) {
        this((int) p.f0x, (int) p.f1y, (int) s.width, (int) s.height);
    }

    public Rect(double[] vals) {
        set(vals);
    }

    public void set(double[] vals) {
        int i;
        int i2;
        int i3 = 0;
        if (vals != null) {
            this.f5x = vals.length > 0 ? (int) vals[0] : 0;
            if (vals.length > 1) {
                i = (int) vals[1];
            } else {
                i = 0;
            }
            this.f6y = i;
            if (vals.length > 2) {
                i2 = (int) vals[2];
            } else {
                i2 = 0;
            }
            this.width = i2;
            if (vals.length > 3) {
                i3 = (int) vals[3];
            }
            this.height = i3;
            return;
        }
        this.f5x = 0;
        this.f6y = 0;
        this.width = 0;
        this.height = 0;
    }

    public Rect clone() {
        return new Rect(this.f5x, this.f6y, this.width, this.height);
    }

    /* renamed from: tl */
    public Point mo306tl() {
        return new Point((double) this.f5x, (double) this.f6y);
    }

    /* renamed from: br */
    public Point mo299br() {
        return new Point((double) (this.f5x + this.width), (double) (this.f6y + this.height));
    }

    public Size size() {
        return new Size((double) this.width, (double) this.height);
    }

    public double area() {
        return (double) (this.width * this.height);
    }

    public boolean contains(Point p) {
        return ((double) this.f5x) <= p.f0x && p.f0x < ((double) (this.f5x + this.width)) && ((double) this.f6y) <= p.f1y && p.f1y < ((double) (this.f6y + this.height));
    }

    public int hashCode() {
        long temp = Double.doubleToLongBits((double) this.height);
        int result = ((int) ((temp >>> 32) ^ temp)) + 31;
        long temp2 = Double.doubleToLongBits((double) this.width);
        int result2 = (result * 31) + ((int) ((temp2 >>> 32) ^ temp2));
        long temp3 = Double.doubleToLongBits((double) this.f5x);
        int result3 = (result2 * 31) + ((int) ((temp3 >>> 32) ^ temp3));
        long temp4 = Double.doubleToLongBits((double) this.f6y);
        return (result3 * 31) + ((int) ((temp4 >>> 32) ^ temp4));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Rect)) {
            return false;
        }
        Rect it = (Rect) obj;
        if (this.f5x == it.f5x && this.f6y == it.f6y && this.width == it.width && this.height == it.height) {
            return true;
        }
        return false;
    }

    public String toString() {
        return "{" + this.f5x + ", " + this.f6y + ", " + this.width + "x" + this.height + "}";
    }
}
